#include <SPI.h>
#include <mcp_can.h>
#include <SoftwareSerial.h>

/*
====================================================================
 SISTEMA DE CONTROL VEHICULAR MEDIANTE CAN + BLUETOOTH
====================================================================

 DESCRIPCIÓN:
 Este programa permite controlar diferentes funciones del vehículo
 mediante comandos recibidos por Bluetooth.

 Flujo general:

 PASO 1:
 El teléfono envía un código por Bluetooth.

 PASO 2:
 Arduino recibe el código y lo compara con la tabla de comandos.

 PASO 3:
 Si existe coincidencia, se genera una trama CAN.

 PASO 4:
 El módulo MCP2515 transmite la información al bus CAN.

====================================================================
*/


//====================================================================
// 1. CONFIGURACIÓN DE HARDWARE
//====================================================================

// Pin CS del módulo MCP2515
#define CAN_CS_PIN 10

// Pines comunicación Bluetooth
#define BT_RX_PIN 3
#define BT_TX_PIN 4


// Creación de objetos de comunicación

MCP_CAN CAN(CAN_CS_PIN);

SoftwareSerial BT(BT_RX_PIN, BT_TX_PIN);


//====================================================================
// 2. TABLA PRINCIPAL DE MENSAJES CAN
//====================================================================

/*

 Cada comando contiene:

 nombre  -> Identificador interno del comando
 id      -> Dirección CAN
 dlc     -> Número de bytes enviados
 data    -> Información transmitida

 Ejemplo:

 PARQ_ON

 CAN ID:
 0x782

 Datos:
 1F 40 48

*/

struct ComandoCAN {

  const char* nombre;

  unsigned long id;

  byte dlc;

  byte data[8];

};



ComandoCAN tablaComandos[] = {


  // ---------------------------------------------------------------
  // ILUMINACIÓN PARQUEO
  // ---------------------------------------------------------------

  {"PARQ_ON",  
   0x782, 
   3, 
   {0x1F,0x40,0x48}},


  {"PARQ_OFF", 
   0x782, 
   3, 
   {0x00,0x40,0x48}},



  // ---------------------------------------------------------------
  // FRENO
  // ---------------------------------------------------------------

  {"FREN_ON",
   0x783,
   1,
   {0x08}},


  {"FREN_OFF",
   0x783,
   1,
   {0x00}},



  // ---------------------------------------------------------------
  // LUCES BAJAS Y ALTAS
  // ---------------------------------------------------------------

  {"BAJAS_ON",
   0x784,
   1,
   {0x61}},


  {"BAJAS_OFF",
   0x784,
   1,
   {0x00}},


  {"ALTAS_ON",
   0x784,
   1,
   {0x63}},


  {"ALTAS_OFF",
   0x784,
   1,
   {0x61}},



  // ---------------------------------------------------------------
  // DIRECCIONALES
  // ---------------------------------------------------------------

  {"DIR_DER_ON",
   0x782,
   3,
   {0x3A,0x40,0x80}},


  {"DIR_DER_OFF",
   0x782,
   3,
   {0x00,0x40,0x80}},



  {"DIR_IZQ_ON",
   0x782,
   3,
   {0x25,0x40,0x80}},


  {"DIR_IZQ_OFF",
   0x782,
   3,
   {0x00,0x40,0x80}},



  // ---------------------------------------------------------------
  // PUERTAS
  // ---------------------------------------------------------------

  {"PTA_DER_ON",
   0x78D,
   3,
   {0x01,0x00,0x00}},


  {"PTA_DER_OFF",
   0x78D,
   3,
   {0x00,0x00,0x00}},


  {"PTA_IZQ_ON",
   0x78C,
   3,
   {0x01,0x00,0x00}},


  {"PTA_IZQ_OFF",
   0x78C,
   3,
   {0x00,0x00,0x00}},



  // ---------------------------------------------------------------
  // CIERRE CENTRALIZADO
  // ---------------------------------------------------------------

  {"ABIERTO",
   0x78A,
   1,
   {0x0A}},


  {"CERRADO",
   0x78A,
   1,
   {0x05}}

};


const int cantidadComandos =
sizeof(tablaComandos) / sizeof(tablaComandos[0]);



//====================================================================
// 3. ESTRUCTURA PARA SECUENCIAS DE SEGURIDAD
//====================================================================

/*

 Las funciones de seguro necesitan enviar varias tramas CAN.

 Ejemplo:

 Activación:
 - Bloqueo puertas
 - Confirmación módulos
 - Activación visual

*/

struct TramaCAN {

  unsigned long id;

  byte dlc;

  byte data[8];

};



//====================================================================
// 4. SECUENCIA DE SEGURO ACTIVADO
//====================================================================


TramaCAN secuenciaSeguroON[] = {


 {0x78A,
  1,
  {0xFF}},


 {0x78C,
  1,
  {0x5E}},


 {0x78D,
  3,
  {0x06,0x00,0x00}},


 {0x78E,
  3,
  {0x06,0x00,0x00}},


 {0x78F,
  1,
  {0x06}},


 {0x790,
  1,
  {0x01}}

};


const int cantidadSeguroON =
sizeof(secuenciaSeguroON) /
sizeof(secuenciaSeguroON[0]);



//====================================================================
// 5. SECUENCIA DE SEGURO DESACTIVADO
//====================================================================


TramaCAN secuenciaSeguroOFF[] = {


 {0x78A,
  1,
  {0x5E}},


 {0x78C,
  1,
  {0x0A}},


 {0x78D,
  3,
  {0x00,0x00,0x00}},


 {0x78E,
  3,
  {0x00,0x00,0x00}},


 {0x78F,
  1,
  {0x00}},


 {0x790,
  1,
  {0x01}}

};


const int cantidadSeguroOFF =
sizeof(secuenciaSeguroOFF) /
sizeof(secuenciaSeguroOFF[0]);



//====================================================================
// 6. MAPEO DE COMANDOS BLUETOOTH
//====================================================================

/*

 Código recibido  -> Acción

 A  = Parqueo ON
 a  = Parqueo OFF

 B  = Freno ON
 b  = Freno OFF

 99 = Seguro ON
 0  = Seguro OFF

*/

struct MapaBluetooth {

  String codigo;

  const char* comando;

};



MapaBluetooth mapaBluetooth[] = {


 {"A","PARQ_ON"},
 {"a","PARQ_OFF"},


 {"B","FREN_ON"},
 {"b","FREN_OFF"},


 {"C","BAJAS_ON"},
 {"c","BAJAS_OFF"},


 {"D","ALTAS_ON"},
 {"d","ALTAS_OFF"},


 {"E","DIR_DER_ON"},
 {"e","DIR_DER_OFF"},


 {"F","DIR_IZQ_ON"},
 {"f","DIR_IZQ_OFF"},


 {"G","PTA_DER_ON"},
 {"g","PTA_DER_OFF"},


 {"H","PTA_IZQ_ON"},
 {"h","PTA_IZQ_OFF"},


 {"I","ABIERTO"},
 {"i","CERRADO"}

};


const int cantidadMapeo =
sizeof(mapaBluetooth) /
sizeof(mapaBluetooth[0]);
//====================================================================
// 7. INICIALIZACIÓN DEL SISTEMA
//====================================================================

/*

 PASO 1:
 Inicia comunicación serial para monitoreo.

 PASO 2:
 Activa comunicación Bluetooth.

 PASO 3:
 Inicializa el controlador CAN MCP2515.

 PASO 4:
 Configura la velocidad del bus CAN.

 En este proyecto:
 CAN = 125 Kbps
 Cristal MCP2515 = 8 MHz

*/

void setup() {


  // Comunicación con monitor serial
  Serial.begin(9600);


  // Comunicación con módulo Bluetooth
  BT.begin(9600);



  Serial.println();
  Serial.println("=================================");
  Serial.println(" SISTEMA CAN + BLUETOOTH INICIADO");
  Serial.println("=================================");



  Serial.println("Inicializando controlador CAN...");



  // Intento de conexión con MCP2515

  while (CAN_OK != CAN.begin(MCP_ANY, CAN_125KBPS, MCP_8MHZ)) {


    Serial.println("CAN no disponible...");
    
    Serial.println("Reintentando conexion...");


    delay(500);

  }



  // Coloca CAN en modo transmisión normal

  CAN.setMode(MCP_NORMAL);



  Serial.println("---------------------------------");
  Serial.println("CAN conectado correctamente");
  Serial.println("Velocidad: 125 Kbps");
  Serial.println("---------------------------------");


  Serial.println("Esperando comandos Bluetooth...");

}




//====================================================================
// 8. CICLO PRINCIPAL DE OPERACIÓN
//====================================================================

/*

 El sistema queda esperando comandos.

 Secuencia:

 PASO 1:
 Bluetooth recibe información.

 PASO 2:
 Se elimina espacios y caracteres
 innecesarios.

 PASO 3:
 Se envía el código a la función
 de interpretación.

*/

void loop() {


  if (BT.available()) {


    // Leer hasta recibir ENTER

    String comandoRecibido =
    BT.readStringUntil('\n');



    // Limpieza del texto

    comandoRecibido.trim();



    // Verificación

    if (comandoRecibido.length() > 0) {


      Serial.print("Comando recibido: ");

      Serial.println(comandoRecibido);



      ejecutarComando(comandoRecibido);


    }

  }


}



//====================================================================
// 9. INTERPRETACIÓN DEL COMANDO RECIBIDO
//====================================================================

/*

 Esta función decide qué acción ejecutar.

 Casos especiales:

 99:
 Activa seguro.

 0:
 Desactiva seguro.


 Cualquier otro código:

 Busca dentro del mapa Bluetooth.

*/

void ejecutarComando(String codigo) {


  codigo.trim();



  //---------------------------------------------------------------
  // CONTROL DE SEGURO ACTIVADO
  //---------------------------------------------------------------


  if (codigo == "99") {


    Serial.println("Solicitud: SEGURO ACTIVADO");


    enviarSecuenciaCAN(
      secuenciaSeguroON,
      cantidadSeguroON,
      "Seguro ON"
    );


    ejecutarParpadeoSeguroON();


    return;

  }



  //---------------------------------------------------------------
  // CONTROL DE SEGURO DESACTIVADO
  //---------------------------------------------------------------


  if (codigo == "0") {


    Serial.println("Solicitud: SEGURO DESACTIVADO");


    enviarSecuenciaCAN(
      secuenciaSeguroOFF,
      cantidadSeguroOFF,
      "Seguro OFF"
    );


    ejecutarParpadeoSeguroOFF();


    return;

  }




  //---------------------------------------------------------------
  // BUSQUEDA EN TABLA DE COMANDOS
  //---------------------------------------------------------------


  for(int i = 0; i < cantidadMapeo; i++) {



    if(mapaBluetooth[i].codigo == codigo) {



      enviarComandoCAN(
        mapaBluetooth[i].comando
      );


      return;


    }


  }




  //---------------------------------------------------------------
  // COMANDO NO EXISTENTE
  //---------------------------------------------------------------


  Serial.print("Codigo desconocido: ");

  Serial.println(codigo);


}
//====================================================================
// 10. ENVÍO DE SECUENCIA COMPLETA CAN
//====================================================================

/*

 Esta función permite enviar varias tramas CAN
 consecutivas.

 Se utiliza principalmente para:

 - Activación del seguro.
 - Desactivación del seguro.

 PASOS:

 1. Recibe una lista de tramas.
 2. Envía cada mensaje CAN.
 3. Espera unos milisegundos para estabilizar el bus.
 4. Muestra el resultado en monitor serial.

*/

void enviarSecuenciaCAN(
  TramaCAN* lista,
  int cantidad,
  const char* descripcion
) {


  Serial.println();
  Serial.println("---------------------------------");
  Serial.println(descripcion);
  Serial.println("---------------------------------");



  for(int i = 0; i < cantidad; i++) {



    byte resultado = CAN.sendMsgBuf(
      lista[i].id,
      0,
      lista[i].dlc,
      lista[i].data
    );



    delay(10);



    Serial.print("ID CAN: 0x");

    Serial.print(lista[i].id, HEX);



    if(resultado == CAN_OK) {


      Serial.println(" -> OK");


    }
    else {


      Serial.println(" -> ERROR");


    }


  }


}



//====================================================================
// 11. EFECTO VISUAL AL ACTIVAR SEGURO
//====================================================================

/*

 Cuando el vehículo se bloquea:

 - Enciende direccional derecha.
 - Enciende direccional izquierda.
 - Mantiene 3 segundos.
 - Apaga ambas.

*/

void ejecutarParpadeoSeguroON() {



  enviarComandoCAN("DIR_DER_ON");


  enviarComandoCAN("DIR_IZQ_ON");



  delay(3000);



  enviarComandoCAN("DIR_DER_OFF");


  enviarComandoCAN("DIR_IZQ_OFF");



}




//====================================================================
// 12. EFECTO VISUAL AL DESACTIVAR SEGURO
//====================================================================

/*

 Cuando el vehículo se desbloquea:

 Realiza tres destellos:

 ON
 Espera
 OFF
 Espera

 Repite 3 veces.

*/

void ejecutarParpadeoSeguroOFF() {



  for(int i = 0; i < 3; i++) {



    enviarComandoCAN("DIR_DER_ON");


    enviarComandoCAN("DIR_IZQ_ON");



    delay(1000);



    enviarComandoCAN("DIR_DER_OFF");


    enviarComandoCAN("DIR_IZQ_OFF");



    delay(300);



  }


}




//====================================================================
// 13. ENVÍO DE UN ÚNICO COMANDO CAN
//====================================================================

/*

 Busca un comando por nombre dentro
 de la tabla principal.

 Ejemplo:

 enviarComandoCAN("FREN_ON");

 Busca:

 ID 0x783
 DATA 08

 Y lo transmite.

*/

void enviarComandoCAN(const char* nombre) {



  for(int i = 0; i < cantidadComandos; i++) {



    if(strcmp(
      tablaComandos[i].nombre,
      nombre
    ) == 0) {



      byte resultado = CAN.sendMsgBuf(
        tablaComandos[i].id,
        0,
        tablaComandos[i].dlc,
        tablaComandos[i].data
      );



      delay(10);



      if(resultado == CAN_OK) {



        Serial.print("CAN enviado: ");

        Serial.println(nombre);



      }
      else {



        Serial.print("Error CAN: ");

        Serial.println(nombre);



      }



      return;



    }



  }



  Serial.print("Comando no encontrado: ");

  Serial.println(nombre);



}




//====================================================================
// 14. FIN DEL PROGRAMA
//====================================================================

/*

 FUNCIONAMIENTO GENERAL:

 Bluetooth
     |
     |
     v
 Arduino
     |
     |
     v
 Tabla de comandos
     |
     |
     v
 MCP2515
     |
     |
     v
 Red CAN del vehículo


 Códigos disponibles:

 A/a  -> Parqueo
 B/b  -> Freno
 C/c  -> Luces bajas
 D/d  -> Luces altas
 E/e  -> Direccional derecha
 F/f  -> Direccional izquierda
 G/g  -> Puerta derecha
 H/h  -> Puerta izquierda
 I/i  -> Abrir/Cerrar


 Funciones especiales:

 99 -> Activar seguro
 0  -> Desactivar seguro


====================================================================
*/